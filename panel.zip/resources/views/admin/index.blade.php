@extends('layouts.admin')
@include('includes.headerAdmin')
@section('content')
<div class="container-fluid">
<span>Logueado</span>
</div>

@endsection