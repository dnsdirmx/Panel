@extends('layouts.empresas')

@section('content')
<div class="container-fluid">
<span>Logueado</span>
</div>

@endsection