<header class="header">
    <!-- <h1 class="headline">Ahorrando ando</small></h1> -->
    <ul class="header-subnav">

        <li><a href="/empresa/newPromo">Nueva promoción</a></li>
        <li><a href="/empresa/logout" >Salir</a></li>
    </ul>
</header>