@extends('layouts.empresas')
@include('includes.headerEmpresa')
@section('content')
	<link rel="stylesheet" href="/css/clockpicker.css" />
	<link rel="stylesheet" href="/css/bootstrap-clockpicker.css" />
    <link rel="stylesheet" href="/css/bootstrap-clockpicker.min.css" />
	<link rel="stylesheet" href="/css/jquery-clockpicker.css" />
	<link rel="stylesheet" href="/css/jquery-clockpicker.min.css" />
	<link rel="stylesheet" href="/css/pikaday.css">

	<div class="container">
		<div class="row">
			<form class="small-centered  columns" onSubmit="return validaCampos()"  method="POST" action="savePromo/{{$promo->id}}" enctype="multipart/form-data">
				<fieldset class="fieldset">
					{!! csrf_field() !!}
					<div class="row">
						<ul class="promo-error">
						@if (count($errors) > 0)
                			@foreach($errors->all() as $error)
                    			<li>{{ $error }}</li>
                			@endforeach	
        				@endif
						</ul>
					</div>
					<!-- hidden fields -->
					<input type="hidden" id="idPromo" value="{{$empresa}}"/>
					<input type="hidden" id="dias" name="dias" required>
					<input type="hidden" id="hsucursales" name="hsucursales">
					<input type="hidden" id="hrestricciones" name="hrestricciones">
			
			

					<!-- visible fields -->
					<div class="horizontal-align large-6 medium-12 small-12 columns">
						<div class="row">
							<div class="small-3 columns ahorrolabel">
                        		<label class="text-right middle">
                        			Opción
                    				<font class="need-field">*</font>
                    			</label>
                    		</div>
                    		
							<div class="small-12 large-9 columns">
                    			<select id="tipo_promo" name="tipo_promo" required>
									@foreach ($tipo_promos as $tipo)
    									<option value="{{ $tipo->id }}" >{{ $tipo->nombre }}</option>
									@endforeach
                    			</select>
                			</div>
						</div>
						<div class="row">
							<div class="small-3 columns ahorrolabel">
								<label class="text-right middle">
									Descripción
									<font class="need-field">*</font>
								</label>
							</div>
							<div class="small-12 large-9 columns">
								<textarea rows="5" id="descripcion" name="descripcion" placeholder="Descripcion " required></textarea>
							</div>
						</div>
						<div class="row">
							<div class="small-4 medium-6 columns ahorrolabel">
								<label class="text-right middle" for="datepicker">
									Dias válidos
								</label>
							</div>
							<div class="small-8 medium-6 columns" id="container">
							</div>
						</div>
					</div>
					<div class="horizontal-align large-6 medium-12 small-12 columns">
						<div class="row">
							<div class="row">
								<span class="small-centered large-centered medium-centered large-4 medium-6 small-12 columns">
									Formato de 24 horas (HH:MM)
								</span>
							</div>
							<div class="row">
								<div class="small-2 columns">
									<label class="text-left middle">
										Horarios
										<font class="need-field">*</font>
									</label>
								</div>
								<div class="small-5 columns">
									<div class="input-group clockpicker">
    									<input type="text" id="hinicia" name="hinicia" pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]" placeholder="Inicio" class="input-group-field" required>
										<span class="input-group-label">Inicia</span>
									</div>
								</div>
								<div class="small-5 columns">
									<div class="input-group clockpicker">
    									<input type="text" id="hfinal" name="hfinal" pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]" placeholder="Finaliza" class="input-group-field" required>
										<span class="input-group-label">Termina</span>
									</div>
								</div>
							</div>
						</div>
						
						<div class="row">
							<span>Sucursales participantes</span>
						</div>
						<div class="row">
							<div class="small-12 medium-10 large-8 columns">
								<select id="sucursales" name="sucursales" multiple required >
									@if (count($sucursales) > 0)
                						@foreach($sucursales as $sucursal)
                    						<option value="{{ $sucursal->id }}">{{ $sucursal->nombre }}</option>
                						@endforeach
        							@endif
								</select>
							</div>
							<div class="small-12 medium-2 large-4 columns">
								<button class="small hollow button" type="button" onClick="addSucur()">
									Agregar sucursales
									<font class="need-field">*</font>
								</button>
							</div>
				
						</div>
						<div class="row">
							<div class="small-12 columns ahorrolabel">
					
							</div>
				
						</div>
						<div class="row" id="sucurContainer">
						</div>

						<div class="row">
							<div class="small-12 columns ahorrolabel">
								<button class="small hollow button" onClick="add()" type="button">
									Agregar restricciones
									<font class="need-field">*</font>
								</button>
							</div>
						</div>
						<div class="row" id="restContainer">
						</div>

						<div class="row">
							<div class="small-5 columns">
								<label for="imagen" class="button">Subir imagen<font class="need-field">*</font></label>   
								<input type="file" id="imagen" name="imagen" class="show-for-sr"  accept=".png,.jpeg,jpeg" required>
							</div>
							<div class="small-5 small-centered columns">
								<input value="Ver ejemplo" class= "small warning hollow button" type="button"/>
							</div>
						</div>

						<div class="row">
							<div class="small-centered columns large-12">
							<button type="submit"  class="success button small-12">
								Envíar
							</button>
						</div>
					</div>
				</fieldset>
			</form>
		</div>
	</div>

	<script type="text/javascript" src="/js/clockpicker.js"></script>
	<script type="text/javascript" src="/js/jquery-1.11.1.js"></script>
	<script type="text/javascript" src="/js/jquery-ui-1.11.1.js"></script>
	<script type="text/javascript" src="/js/jquery-ui.multidatespicker.js"></script>
	<script type="text/javascript" src="/js/jquery-clockpicker.min.js"></script>
	<script type="text/javascript" src="/js/bootstrap-clockpicker.js"></script>
	<script type="text/javascript" src="/js/jquery-clockpicker.js"></script>
	<script type="text/javascript" src="/js/bootstrap-clockpicker.min.js"></script>
	<script type="text/javascript" src="/js/pikaday.js"></script>
	<script type="text/javascript" src="/js/newpromo.js"></script>
@endsection