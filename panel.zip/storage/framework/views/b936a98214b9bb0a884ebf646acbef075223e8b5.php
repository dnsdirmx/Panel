<?php echo $__env->make('includes.headerAccesoEmp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/css/empresa.css" />
<link rel="stylesheet" href="/css/panel.css" />

<div class="container-fluid">
	<div class="row" >
		<div class="col-xs-12 col-sm-10 col-sm-offset-1 col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2">
			<div class="panel">
				<div class="panel-heading nav navbar-inverse">
						<ul class="nav navbar-nav">
                  			<li>
								Registrarse
							</li>
						</ul>
				</div><div class="panel-body">
                    <form method="POST" action="<?php echo e(url('/empresa-register')); ?>">
                        <fieldset>
                            <?php echo e(csrf_field()); ?>

                            <div>
                            <?php if(count($errors) > 0): ?>
                                <ul>
                                    <?php foreach($errors->all() as $error): ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label class="col-sm-4 control-label">
                                    Nombre del contacto <font class="need-field">*</font>
                                </label>
                                <div class="col-sm-8">
                                    <input class="form-control margin-bottom" type="text" name="nombre_contacto" id="nombre_contacto" placeholder="Nombre del contacto" required/>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="col-sm-4 control-label">
                                    Nombre de la empresa<font class="need-field">*</font>
                                </label>
                                <div class="col-sm-8">
                                    <input class="form-control margin-bottom" type="text" name="name" id="name" placeholder="Nombre de la empresa" required/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">
                                    Estado<font class="need-field">*</font>
                                </label>
                                <div class="col-sm-8">
                                    <select class="form-control margin-bottom" onChange="seleccionaEstado()" name="estado" id="estado" required>
                                        <?php foreach($estados as $estado): ?>
                                            <option  value="<?php echo e($estado->cve_ent); ?>"><?php echo e($estado->nom_ent); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">
                                    Ciudad<font class="need-field">*</font>
                                </label>
                                <div class="col-sm-8">
                                    <select class="form-control margin-bottom" name="ciudad" id="ciudad" required>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">
                                    Dirección<font class="need-field">*</font>
                                </label>
                                <div class="col-sm-8">
                                    <input class="form-control margin-bottom" type="text" name="direccion" id="direccion" placeholder="Dirección" required/>
                                </div>
                            </div>

                            <label class="col-sm-4 control-label">
                                Teléfono<font class="need-field">*</font>
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control margin-bottom" type="text" name="telefono" id="telefono" placeholder="Teléfono" required/>
                            </div>

                            <label class="col-sm-4 control-label">
                                Giro comercial<font class="need-field">*</font>
                            </label>
                            <div class="col-sm-8">
                                <select class="form-control margin-bottom" name="giro" id="giro" required>
                                    <?php foreach($giros as $giro): ?>
                                        <option value="<?php echo e($giro->id); ?>"><?php echo e($giro->nombre); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <label class="col-sm-4 control-label">
                                Correo electrónico<font class="need-field">*</font>
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control margin-bottom" type="email" name="email" id="email" placeholder="Email" required/>
                            </div>
                            <label class="col-sm-4 control-label">
                                Contraseña<font class="need-field">*</font>
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control margin-bottom" type="password" name="password" id="password" placeholder="Password" id="password" required/>
                            </div>    
                            
                            <label class="col-sm-4 control-label">
                                Confirma la contraseña<font class="need-field">*</font>
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control margin-bottom" type="password" name="password_confirmation" id="password_confirmation" placeholder="Confirma el password" title="ES necesario que el password sea similar" required/>
                            </div>
                                        
                            <label class="col-sm-4 control-label">
                                Código promotor<font class="optional-field">(Opcional)</font>
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control margin-bottom" type="text" name="cod_promotor" id="cod_promotor" placeholder="Codigo promotor" />
                            </div>
                            <div class="form-group">
                                <label class="col-sm-8 col-sm-offset-4 control-label">
                                    <input class="checkbox" type="checkbox" required>Acepto<a href="<?php echo e(url('terminosycondiciones')); ?>"> Términos y Condiciones </link>
                                    <font class="need-field">*</font>
                                </label>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success col-sm-4 col-sm-offset-4">Registrarse</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empresas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>