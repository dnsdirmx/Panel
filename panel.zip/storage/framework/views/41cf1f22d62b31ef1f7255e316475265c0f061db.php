<?php echo $__env->make('includes.headerAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="table-responsive col-lg-8 col-lg-offset-2 table-bordered">
            <table class="table table-condensed table-hover">
                <thead>
                    <tr>
                        <th>Empresa</th>
                        <th>Contacto</th>
                        <th>Dirección</th>
                        <th>Teléfono</th>
                        <th>Email</th>
                        <th>Ciudad</th>
                        <th>Estado</th>
                        <th>Promotor</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($empresas as $empresa): ?>
                    <tr>
                        <td><?php echo e($empresa->name); ?></td>
                        <td><?php echo e($empresa->nombre_contacto); ?></td>
                        <td><?php echo e($empresa->direccion); ?></td>
                        <td><?php echo e($empresa->telefono); ?></td>
                        <td><?php echo e($empresa->email); ?></td>
                        <td>
                            <?php foreach($ciudades as $ciudad): ?>
                                <?php if($ciudad->cve_mun == $empresa->ciudad && $ciudad->cve_ent == $empresa->estado): ?>
                                    <?php echo e($ciudad->nom_mun); ?>

                                <?php endif; ?>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <?php foreach($estados as $estado): ?>
                                <?php if( $estado->cve_ent == $empresa->estado): ?>
                                    <?php echo e($estado->nom_ent); ?>

                                <?php endif; ?>
                            <?php endforeach; ?>
                        </td>
                        <td><?php echo e($empresa->cod_promotor); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                </tfoot>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>