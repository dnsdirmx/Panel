<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<span>Logueado</span>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empresas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>