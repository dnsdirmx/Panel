<?php echo $__env->make('includes.headerEmpresa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/css/empresa.css" />
<div class="container">

    <?php if(isset($message)): ?>
    <div class="row">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"></div>
                <div class="panel-body">
                    Sesión iniciada
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empresas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>