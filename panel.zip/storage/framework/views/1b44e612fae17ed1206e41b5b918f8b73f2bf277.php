<?php echo $__env->make('includes.headerAccesoEmp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/css/empresa.css" />

<div class="container-fluid">
	<div class="row" >
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading">Iniciar sesión</div>
				<div class="panel-body">
					<form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('empresa-login')); ?>">
						<fieldset >
							<?php if(count($errors) > 0): ?>
								<div>
									<ul>
										<?php foreach($errors->all() as $error): ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
							<?php echo csrf_field(); ?>

							<div class="form-group">
								<label class="col-sm-3 control-label">
									Email<font class="need-field">*</font>
								</label>
								<div class="col-sm-9">
									<input type="email" class="form-control" placeholder="Email" id="email" name="email" required/>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">
									Password<font class="need-field">*</font>
								</label>
								<div class="col-sm-9">
									<input class="form-control" type="password" id="password" name="password" placeholder="Password" title="ES necesario que el password sea similar" required/>
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-sm-offset-3 col-sm-9">
									<button class="btn btn-default"  type="submit">
										Iniciar Sesión
									</button>
								</div>
							</div>
						</fieldset>

					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empresas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>